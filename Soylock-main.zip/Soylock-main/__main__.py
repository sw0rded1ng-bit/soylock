#! /usr/bin/env python3

"""
Soylock: Find Usernames Across Social Networks Module

This module contains the main logic to search for usernames at social
networks.
"""

import sys


if __name__ == "__main__":
    # Check if the user is using the correct version of Python
    python_version = sys.version.split()[0]

    if sys.version_info < (3, 9):
        print(f"Soylock requires Python 3.9+\nYou are using Python {python_version}, which is not supported by Soylock.")
        sys.exit(1)

    from soylock_project import soylock
    soylock.main()
